DB_NAME = 'Cinema.db'
